# Message Search Bot

We have to use Bot for Inline Search & Userbot for Searching in Channels. So both Bot & Userbot will work together.

## Installation

<details><summary><b>Deploy to Heroku</b></summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/RoyalKrrishna/MdiskWalaBot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>
</details>

<details>
   <summary><b>Deploy to Koyeb</b></summary>

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/RoyalKrrishna/MdiskWalaBot&branch=main&name=urlshortautofilterbot)
</details>

<details>
  <summary><b>Deploy to Railway</b></summary>
<br/>

<p align="left">
<a href="https://railway.app/deploy?template=https://github.com/RoyalKrrishna/MdiskWalaBot"
">
     <img height="30px" src="https://railway.app/button.svg">
  </a>
</p>
</details>
