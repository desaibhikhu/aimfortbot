echo "Cloning Repo...."
git clone https://github.com/RoyalKrrishna/MdiskWalaBot /MdiskWalaBot
cd /MdiskWalaBot
pip3 install -r requirements.txt
echo "Starting Bot...."
python3 main.py
